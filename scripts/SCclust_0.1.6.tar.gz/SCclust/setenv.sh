
export PATH=$HOME/Local/anaconda3_5_0/bin:$PATH
source activate scclust3

export PATH=$(pwd)/tools:$PATH
export PYTHONPATH=$(pwd)/scpipe:$PYTHONPATH

