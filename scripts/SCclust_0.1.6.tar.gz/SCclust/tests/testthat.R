library(testthat)
library(SCclust)

test_check("SCclust")
