# SCclust
Clustering of Single Cell Sequencing Copy Number Profiles to Identify Clones

## Install
devtools::install_github("JunyanSong/SCclust")

## Usage Tips 
See vignettes.
New features are adding to the package.
