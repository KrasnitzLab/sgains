#'@title hg19.badbins.5k
#'
#'@description Bad bins to be filtered for 5k bins.
#'@name badbins.5k
#'@docType data
#'@usage badbins.5k
#'@format A vector
#'@keywords datasets
"badbins.5k"

#'@title hg19.badbins.20k
#'
#'@description Bad bins to be filtered for 20k bins.
#'@name badbins.20k
#'@docType data
#'@usage badbins.20k
#'@format A vector
#'@keywords datasets
NULL


#'@title hg19.badbins.50k
#'
#'@description Bad bins to be filtered for 50k bins.
#'@name badbins.50k
#'@docType data
#'@usage badbins.50k
#'@format A vector
#'@keywords datasets
NULL



#'@title hg19.varbin.gc.5k
#'
#'@description The GC content for each bin (5k bins).
#'@name varbin.gc.5k
#'@docType data
#'@usage varbin.gc.5k
#'@format A data matirx
#'@keywords datasets
NULL


#'@title hg19.varbin.gc.20k
#'
#'@description The GC content for each bin (20k bins).
#'@name varbin.gc.20k
#'@docType data
#'@usage varbin.gc.20k
#'@format A data matirx
#'@keywords datasets
NULL

#'@title hg19.varbin.gc.50k
#'
#'@description The GC content for each bin (50k bins).
#'@name varbin.gc.50k
#'@docType data
#'@usage varbin.gc.50k
#'@format A data matirx
#'@keywords datasets
NULL



#'@title centromere areas annotation
#'
#'@description Centromere areas to be filtered out.
#'@name dropareas
#'@docType data
#'@usage dropareas
#'@format A data matirx
#'@keywords datasets
NULL
