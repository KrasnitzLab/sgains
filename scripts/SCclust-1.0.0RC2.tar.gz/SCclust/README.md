# SCclust R package

**Please note that this software is still under construction and not ready for general use**

The SCclust package implements feature selection based on
breakpoints, permutations for FDRs for Fisher test p-values and identification
of the clone structure in single cell copy number profiles.