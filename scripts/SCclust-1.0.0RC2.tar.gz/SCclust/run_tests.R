# 
# Author: lubo
# Created: Apr 18, 2018
###############################################################################

library(testthat)

library(futile.logger)
flog.threshold(DEBUG)

devtools::load_all(".")

testthat::test_dir("tests/testthat")
